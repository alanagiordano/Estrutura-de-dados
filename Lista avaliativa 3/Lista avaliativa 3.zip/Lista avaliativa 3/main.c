#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Livro {
    char nome[100];
    char autor[100];
} Livro;

typedef struct No {
    Livro livro;
    struct No* prox;
} No;

No* criarNo(Livro livro) {
    No* novoNo = (No*)malloc(sizeof(No));
    novoNo->livro = livro;
    novoNo->prox = NULL;
    return novoNo;
}

void inserirNoNaFila(No** fila, Livro livro) {
    No* novoNo = criarNo(livro);
    if (*fila == NULL) {
        *fila = novoNo;
    } else {
        No* atual = *fila;
        while (atual->prox != NULL) {
            atual = atual->prox;
        }
        atual->prox = novoNo;
    }
}

void inserirNoNaPilha(No** pilha, Livro livro) {
    No* novoNo = criarNo(livro);
    novoNo->prox = *pilha;
    *pilha = novoNo;
}

Livro removerNoDaFila(No** fila) {
    if (*fila == NULL) {
        Livro livroVazio;
        strcpy(livroVazio.nome, "");
        strcpy(livroVazio.autor, "");
        return livroVazio;
    } else {
        Livro livroRemovido = (*fila)->livro;
        No* temp = *fila;
        *fila = (*fila)->prox;
        free(temp);
        return livroRemovido;
    }
}

Livro removerNoDaPilha(No** pilha) {
    if (*pilha == NULL) {
        Livro livroVazio;
        strcpy(livroVazio.nome, "");
        strcpy(livroVazio.autor, "");
        return livroVazio;
    } else {
        Livro livroRemovido = (*pilha)->livro;
        No* temp = *pilha;
        *pilha = (*pilha)->prox;
        free(temp);
        return livroRemovido;
    }
}

void exibirFila(No* fila) {
    No* atual = fila;
    while (atual != NULL) {
        printf("%s;%s\n", atual->livro.nome, atual->livro.autor);
        atual = atual->prox;
    }
}

void exibirPilha(No* pilha) {
    No* atual = pilha;
    while (atual != NULL) {
        printf("%s;%s\n", atual->livro.nome, atual->livro.autor);
        atual = atual->prox;
    }
}

int main() {
    No* fila = NULL;
    No* pilha = NULL;

    FILE* filaFile = fopen("fila_de_livros.txt", "r");
    if (filaFile == NULL) {
        perror("Erro ao abrir o arquivo fila_de_livros.txt");
        return 1;
    }

    char linha[256];
    while (fgets(linha, sizeof(linha), filaFile)) {
        char nome[100];
        char autor[100];
        sscanf(linha, "%[^;];%[^;]", nome, autor);
        Livro livro;
        strcpy(livro.nome, nome);
        strcpy(livro.autor, autor);
        inserirNoNaFila(&fila, livro);
    }

    fclose(filaFile);

    FILE* pilhaFile = fopen("pilha_de_livros.txt", "r");
    if (pilhaFile == NULL) {
        perror("Erro ao abrir o arquivo pilha_de_livros.txt");
        return 1;
    }

    while (fgets(linha, sizeof(linha), pilhaFile)) {
        char nome[100];
        char autor[100];
        sscanf(linha, "%[^;];%[^;]", nome, autor);
        Livro livro;
        strcpy(livro.nome, nome);
        strcpy(livro.autor, autor);
        inserirNoNaPilha(&pilha, livro);
    }

    fclose(pilhaFile);

    int opcao;
    do {
        printf("\nMenu:\n");
        printf("1. Exibir fila de livros\n");
        printf("2. Inserir livro na fila\n");
        printf("3. Inserir livro na pilha\n");
        printf("4. Remover livro da fila\n");
        printf("5. Remover livro da pilha\n");
        printf("0. Sair\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                printf("\nFila de livros (FIFO):\n");
                exibirFila(fila);
                break;
            case 2:
                printf("\nInserir livro na fila:\n");
                Livro novoLivro;
                printf("Nome do livro: ");
                scanf(" %[^\n]", novoLivro.nome);
                printf("Nome do autor: ");
                scanf(" %[^\n]", novoLivro.autor);
                inserirNoNaFila(&fila, novoLivro);
                filaFile = fopen("fila_de_livros.txt", "a");
                if (filaFile != NULL) {
                    fprintf(filaFile, "%s;%s\n", novoLivro.nome, novoLivro.autor);
                    fclose(filaFile);
                } else {
                    perror("Erro ao abrir o arquivo fila_de_livros.txt");
                }
                break;
            case 3:
                printf("\nInserir livro na pilha:\n");
                Livro novoLivroPilha;
                printf("Nome do livro: ");
                scanf(" %[^\n]", novoLivroPilha.nome);
                printf("Nome do autor: ");
                scanf(" %[^\n]", novoLivroPilha.autor);
                inserirNoNaPilha(&pilha, novoLivroPilha);
                pilhaFile = fopen("pilha_de_livros.txt", "a");
                if (pilhaFile != NULL) {
                    fprintf(pilhaFile, "%s;%s\n", novoLivroPilha.nome, novoLivroPilha.autor);
                    fclose(pilhaFile);
                } else {
                    perror("Erro ao abrir o arquivo pilha_de_livros.txt");
                }
                break;
            case 4:
                printf("\nRemover livro da fila:\n");
                Livro livroRemovidoFila = removerNoDaFila(&fila);
                if (strcmp(livroRemovidoFila.nome, "") == 0) {
                    printf("A fila está vazia.\n");
                } else {
                    printf("Livro removido: %s;%s\n", livroRemovidoFila.nome, livroRemovidoFila.autor);
                    filaFile = fopen("fila_de_livros.txt", "w");
                    if (filaFile != NULL) {
                        No* atual = fila;
                        while (atual != NULL) {
                            fprintf(filaFile, "%s;%s\n", atual->livro.nome, atual->livro.autor);
                            atual = atual->prox;
                        }
                        fclose(filaFile);
                    } else {
                        perror("Erro ao abrir o arquivo fila_de_livros.txt");
                    }
                }
                break;
            case 5:
                printf("\nRemover livro da pilha:\n");
                Livro livroRemovidoPilha = removerNoDaPilha(&pilha);
                if (strcmp(livroRemovidoPilha.nome, "") == 0) {
                    printf("A pilha está vazia.\n");
                } else {
                    printf("Livro removido: %s;%s\n", livroRemovidoPilha.nome, livroRemovidoPilha.autor);
                    pilhaFile = fopen("pilha_de_livros.txt", "w");
                    if (pilhaFile != NULL) {
                        No* atual = pilha;
                        while (atual != NULL) {
                            fprintf(pilhaFile, "%s;%s\n", atual->livro.nome, atual->livro.autor);
                            atual = atual->prox;
                        }
                        fclose(pilhaFile);
                    } else {
                        perror("Erro ao abrir o arquivo pilha_de_livros.txt");
                    }
                }
                break;
            case 0:
                printf("Saindo do programa...\n");
                break;
            default:
                printf("Opção inválida. Tente novamente.\n");
        }
    } while (opcao != 0);

    while (fila != NULL) {
        No* temp = fila;
        fila = fila->prox;
        free(temp);
    }
    while (pilha != NULL) {
        No* temp = pilha;
        pilha = pilha->prox;
        free(temp);
    }

    return 0;
}